'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var pluginSdk = require('@xpert-ai/plugin-sdk');
var zod = require('zod');
var cp = require('node:child_process');
var path = require('node:path');
var common = require('@nestjs/common');
var i18next = require('i18next');
var fs = require('node:fs');
var http = require('node:http');
var os = require('node:os');
var net = require('node:net');

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
typeof SuppressedError === "function" ? SuppressedError : function _SuppressedError(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

var name = "@xpert-ai/plugin-local-shell-sandbox";
var version = "0.2.2";
var manifest = {
    name: name,
    version: version};

function _array_like_to_array$2(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_without_holes(arr) {
    if (Array.isArray(arr)) return _array_like_to_array$2(arr);
}
function asyncGeneratorStep$2(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator$2(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep$2(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep$2(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _class_call_check$3(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties$2(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class$2(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties$2(Constructor.prototype, protoProps);
    return Constructor;
}
function _define_property$2(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _instanceof$2(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function _iterable_to_array$1(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _non_iterable_spread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread$1(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$2(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys$1(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props$1(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys$1(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _to_consumable_array(arr) {
    return _array_without_holes(arr) || _iterable_to_array$1(arr) || _unsupported_iterable_to_array$2(arr) || _non_iterable_spread();
}
function _unsupported_iterable_to_array$2(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$2(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$2(o, minLen);
}
function _ts_generator$2(thisArg, body) {
    var f, y, t, g, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    };
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(_)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
var DEFAULT_TERMINAL_COLS = 120;
var DEFAULT_TERMINAL_ROWS = 32;
var TERMINAL_BASH_ARGS = [
    "--noprofile",
    "--norc"
];
var ANSI_ESCAPE = "\x1b";
var ANSI_NON_PRINTING_PREFIX = "\x01";
var ANSI_NON_PRINTING_SUFFIX = "\x02";
var TERMINAL_PROMPT = "".concat(ANSI_NON_PRINTING_PREFIX).concat(ANSI_ESCAPE, "[1;36m").concat(ANSI_NON_PRINTING_SUFFIX, "xpert@sandbox").concat(ANSI_NON_PRINTING_PREFIX).concat(ANSI_ESCAPE, "[0m").concat(ANSI_NON_PRINTING_SUFFIX, " ").concat(ANSI_NON_PRINTING_PREFIX).concat(ANSI_ESCAPE, "[33m").concat(ANSI_NON_PRINTING_SUFFIX, "\\w").concat(ANSI_NON_PRINTING_PREFIX).concat(ANSI_ESCAPE, "[0m").concat(ANSI_NON_PRINTING_SUFFIX, " $ ");
var TERMINAL_ZSH_PROMPT = "%F{cyan}xpert@sandbox%f %F{yellow}%~%f $ ";
var TERMINAL_LS_COLORS = "ExFxCxDxBxegedabagacad";
var cachedNodePtyModule = null;
function buildNodePtyLoadError(error) {
    var detail = _instanceof$2(error, Error) ? error.message : String(error);
    return new Error('Failed to load terminal support dependency "node-pty". Install or rebuild it for '.concat(process.platform, "-").concat(process.arch, ". ") + "In Docker images, ensure python3, make, and g++ are available during pnpm install. Original error: ".concat(detail));
}
function getNodePtyModule() {
    if (cachedNodePtyModule) {
        return cachedNodePtyModule;
    }
    try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        var module = require("node-pty");
        if (typeof module.spawn !== "function") {
            throw new Error("node-pty did not export a spawn function.");
        }
        cachedNodePtyModule = module;
        return module;
    } catch (error) {
        throw buildNodePtyLoadError(error);
    }
}
function tryEnsureNodePtySpawnHelperExecutable() {
    try {
        var packageRoot = path.dirname(require.resolve("node-pty/package.json"));
        var helperCandidates = [
            path.join(packageRoot, "build", "Release", "spawn-helper"),
            path.join(packageRoot, "prebuilds", "".concat(process.platform, "-").concat(process.arch), "spawn-helper")
        ];
        var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
        try {
            for(var _iterator = helperCandidates[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                var helperPath = _step.value;
                if (!fs.existsSync(helperPath)) {
                    continue;
                }
                if ((fs.statSync(helperPath).mode & 73) === 0) {
                    fs.chmodSync(helperPath, 493);
                }
                return;
            }
        } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
        } finally{
            try {
                if (!_iteratorNormalCompletion && _iterator.return != null) {
                    _iterator.return();
                }
            } finally{
                if (_didIteratorError) {
                    throw _iteratorError;
                }
            }
        }
    } catch (e) {
    // If discovery fails we still attempt to open the PTY normally.
    }
}
function clampTerminalSize(value, fallback) {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.max(1, Math.trunc(value)) : fallback;
}
function resolveFallbackShell() {
    var _process_env_SHELL;
    var shell = (_process_env_SHELL = process.env["SHELL"]) === null || _process_env_SHELL === void 0 ? void 0 : _process_env_SHELL.trim();
    if (shell) {
        var shellName = path.basename(shell);
        if (shellName === "bash") {
            return {
                file: shell,
                args: _to_consumable_array(TERMINAL_BASH_ARGS)
            };
        }
        if (shellName === "zsh") {
            return {
                file: shell,
                args: [
                    "-f"
                ]
            };
        }
        if (shellName === "fish") {
            return {
                file: shell,
                args: [
                    "--no-config"
                ]
            };
        }
        return {
            file: shell,
            args: []
        };
    }
    return {
        file: "/bin/sh",
        args: []
    };
}
function resolveTerminalShell() {
    if (fs.existsSync("/bin/bash")) {
        return {
            file: "/bin/bash",
            args: _to_consumable_array(TERMINAL_BASH_ARGS)
        };
    }
    return resolveFallbackShell();
}
var LocalShellTerminalSession = /*#__PURE__*/ function() {
    function LocalShellTerminalSession(ptyProcess) {
        _class_call_check$3(this, LocalShellTerminalSession);
        _define_property$2(this, "ptyProcess", void 0);
        this.ptyProcess = ptyProcess;
    }
    _create_class$2(LocalShellTerminalSession, [
        {
            key: "write",
            value: function write(data) {
                this.ptyProcess.write(data);
            }
        },
        {
            key: "resize",
            value: function resize(cols, rows) {
                this.ptyProcess.resize(clampTerminalSize(cols, DEFAULT_TERMINAL_COLS), clampTerminalSize(rows, DEFAULT_TERMINAL_ROWS));
            }
        },
        {
            key: "close",
            value: function close() {
                this.ptyProcess.kill();
            }
        }
    ]);
    return LocalShellTerminalSession;
}();
function openLocalTerminal(workingDirectory, options) {
    return _openLocalTerminal.apply(this, arguments);
} 
function _openLocalTerminal() {
    _openLocalTerminal = _async_to_generator$2(function(workingDirectory, options) {
        var spawn, shell, _process_env_HOME, ptyProcess;
        return _ts_generator$2(this, function(_state) {
            tryEnsureNodePtySpawnHelperExecutable();
            spawn = getNodePtyModule().spawn;
            shell = resolveTerminalShell();
            ptyProcess = spawn(shell.file, shell.args, {
                cwd: workingDirectory,
                cols: clampTerminalSize(options.cols, DEFAULT_TERMINAL_COLS),
                rows: clampTerminalSize(options.rows, DEFAULT_TERMINAL_ROWS),
                env: _object_spread_props$1(_object_spread$1({}, process.env), {
                    HOME: (_process_env_HOME = process.env["HOME"]) !== null && _process_env_HOME !== void 0 ? _process_env_HOME : os.homedir(),
                    TERM: "xterm-256color",
                    COLORTERM: "truecolor",
                    FORCE_COLOR: "1",
                    CLICOLOR: "1",
                    LSCOLORS: TERMINAL_LS_COLORS,
                    BASH_ENV: "",
                    ENV: "",
                    PS1: TERMINAL_PROMPT,
                    PROMPT: TERMINAL_ZSH_PROMPT,
                    ZDOTDIR: "/dev/null"
                }),
                name: "xterm-256color"
            });
            ptyProcess.onData(function(data) {
                options.onOutput(data);
            });
            ptyProcess.onExit(function(event) {
                options.onExit({
                    exitCode: event.exitCode,
                    signal: event.signal
                });
            });
            return [
                2,
                new LocalShellTerminalSession(ptyProcess)
            ];
        });
    });
    return _openLocalTerminal.apply(this, arguments);
}

function _instanceof$1(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function isObjectLike(value) {
    return typeof value === "object" && value !== null;
}
function isNonEmptyString(value) {
    return typeof value === "string" && value.trim().length > 0;
}
function isFiniteNumber(value) {
    return typeof value === "number" && Number.isFinite(value);
}
function normalizeHeaderValue(value) {
    var _value_toString;
    return Array.isArray(value) ? value.join(", ") : (_value_toString = value === null || value === void 0 ? void 0 : value.toString()) !== null && _value_toString !== void 0 ? _value_toString : "";
}
function shouldRewritePreviewResponse(headers, method) {
    if (method === "HEAD") {
        return false;
    }
    if (normalizeHeaderValue(headers["content-encoding"]).trim()) {
        return false;
    }
    var contentType = normalizeHeaderValue(headers["content-type"]).toLowerCase();
    return contentType.includes("text/html") || contentType.includes("application/xhtml+xml") || contentType.includes("text/css") || contentType.includes("javascript") || contentType.includes("ecmascript");
}
function shouldForwardProxyResponseHeader(name, rewriteBody) {
    var normalized = name.toLowerCase();
    if (normalized === "connection" || normalized === "keep-alive" || normalized === "proxy-authenticate" || normalized === "proxy-authorization" || normalized === "service-worker-allowed" || normalized === "set-cookie" || normalized === "te" || normalized === "trailer" || normalized === "transfer-encoding" || normalized === "upgrade") {
        return false;
    }
    return !rewriteBody || normalized !== "content-length" && normalized !== "content-encoding";
}
function normalizePreviewProxyBasePath(service) {
    if (!isNonEmptyString(service.previewUrl)) {
        return null;
    }
    try {
        var pathname = new URL(service.previewUrl, "http://xpert.local").pathname;
        return pathname.endsWith("/") ? pathname : "".concat(pathname, "/");
    } catch (e) {
        return service.previewUrl.endsWith("/") ? service.previewUrl : "".concat(service.previewUrl, "/");
    }
}
function rewritePreviewRootPath(pathname, proxyBasePath) {
    if (!pathname.startsWith("/") || pathname.startsWith("//") || pathname.startsWith(proxyBasePath)) {
        return pathname;
    }
    return "".concat(proxyBasePath).concat(pathname.replace(/^\/+/, ""));
}
function rewritePreviewTextResponse(content, proxyBasePath) {
    return content.replace(/(["'`])\/(?!\/)([^"'`\s<>)]*)/g, function(_match, quote, pathname) {
        return "".concat(quote).concat(rewritePreviewRootPath("/".concat(pathname), proxyBasePath));
    }).replace(/(\b(?:src|href|action|poster|data|xlink:href)\s*=\s*)(\/(?!\/)[^\s"'<>]*)/gi, function(_match, prefix, pathname) {
        return "".concat(prefix).concat(rewritePreviewRootPath(pathname, proxyBasePath));
    }).replace(/(url\(\s*)(\/(?!\/)[^"')\s]+)(\s*\))/gi, function(_match, prefix, pathname, suffix) {
        return "".concat(prefix).concat(rewritePreviewRootPath(pathname, proxyBasePath)).concat(suffix);
    });
}
function normalizeServiceEnv(entries) {
    var env = {};
    var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
    try {
        for(var _iterator = (entries !== null && entries !== void 0 ? entries : [])[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
            var entry = _step.value;
            if (!entry.name.trim()) {
                continue;
            }
            env[entry.name] = entry.value;
        }
    } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
    } finally{
        try {
            if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
            }
        } finally{
            if (_didIteratorError) {
                throw _iteratorError;
            }
        }
    }
    return env;
}
function isProcessMissingError(error) {
    return _instanceof$1(error, Error) && "code" in error && error.code === "ESRCH";
}
function killProcessGroup(processId, signal) {
    if (!processId) {
        return;
    }
    if (process.platform === "win32") {
        process.kill(processId, signal);
        return;
    }
    process.kill(-processId, signal);
}
function sleep(ms) {
    return new Promise(function(resolve) {
        setTimeout(resolve, ms);
    });
}
function resolveServiceLogPaths(metadata, cwd, serviceId) {
    if (isObjectLike(metadata)) {
        var candidate = metadata;
        if (isObjectLike(candidate.logs)) {
            var _candidate_logs = candidate.logs, stdoutPath = _candidate_logs.stdoutPath, stderrPath = _candidate_logs.stderrPath;
            if (isNonEmptyString(stdoutPath) && isNonEmptyString(stderrPath)) {
                return {
                    stdoutPath: stdoutPath,
                    stderrPath: stderrPath
                };
            }
        }
    }
    var basePath = path.join(cwd, ".xpert", "managed-services", serviceId);
    return {
        stdoutPath: path.join(basePath, "stdout.log"),
        stderrPath: path.join(basePath, "stderr.log")
    };
}
function ensureServiceLogDirectory(logPaths) {
    fs.mkdirSync(path.dirname(logPaths.stdoutPath), {
        recursive: true
    });
    fs.mkdirSync(path.dirname(logPaths.stderrPath), {
        recursive: true
    });
}
function readLogTail(filePath, maxLines) {
    if (!fs.existsSync(filePath)) {
        return "";
    }
    var content = fs.readFileSync(filePath, "utf8");
    var lines = content.split(/\r?\n/);
    return lines.slice(Math.max(0, lines.length - maxLines)).join("\n").trim();
}
var MAX_SERVICE_READY_TEXT_BYTES = 4096;
function normalizeServiceReadyText(value) {
    if (!isNonEmptyString(value)) {
        return null;
    }
    if (Buffer.byteLength(value, "utf8") > MAX_SERVICE_READY_TEXT_BYTES) {
        var fallbackMessage = "Service readiness text must not exceed ".concat(MAX_SERVICE_READY_TEXT_BYTES, " UTF-8 bytes.");
        throw new Error(i18next.t("server-ai:Error.SandboxServiceReadyTextTooLarge", {
            defaultValue: fallbackMessage,
            maxBytes: MAX_SERVICE_READY_TEXT_BYTES
        }) || fallbackMessage);
    }
    return value;
}
function doesServiceLogMatch(logPaths, readyText) {
    return "".concat(readLogTail(logPaths.stdoutPath, 200), "\n").concat(readLogTail(logPaths.stderrPath, 200)).includes(readyText);
}
function waitForPort(port, timeoutMs) {
    return new Promise(function(resolve, reject) {
        var socket = net.connect({
            host: "127.0.0.1",
            port: port
        });
        var timer = setTimeout(function() {
            socket.destroy();
            reject(new Error("Timed out while waiting for port ".concat(port)));
        }, timeoutMs);
        socket.once("connect", function() {
            clearTimeout(timer);
            socket.end();
            resolve();
        });
        socket.once("error", function(error) {
            clearTimeout(timer);
            socket.destroy();
            reject(error);
        });
    });
}
function ensurePortIsAvailable(port) {
    return new Promise(function(resolve, reject) {
        var server = net.createServer();
        server.once("error", function(error) {
            server.close();
            if (error.code === "EADDRINUSE") {
                reject(new Error("Port ".concat(port, " is already in use.")));
                return;
            }
            reject(error);
        });
        server.listen(port, "127.0.0.1", function() {
            server.close(function(error) {
                if (error) {
                    reject(error);
                    return;
                }
                resolve();
            });
        });
    });
}

function _array_like_to_array$1(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes$1(arr) {
    if (Array.isArray(arr)) return arr;
}
function _assert_this_initialized(self) {
    if (self === void 0) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
}
function asyncGeneratorStep$1(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator$1(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep$1(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep$1(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _class_call_check$2(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties$1(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class$1(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties$1(Constructor.prototype, protoProps);
    return Constructor;
}
function _define_property$1(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _get_prototype_of(o) {
    _get_prototype_of = Object.setPrototypeOf ? Object.getPrototypeOf : function getPrototypeOf(o) {
        return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _get_prototype_of(o);
}
function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
        constructor: {
            value: subClass,
            writable: true,
            configurable: true
        }
    });
    if (superClass) _set_prototype_of(subClass, superClass);
}
function _iterable_to_array_limit$1(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest$1() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _object_spread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = arguments[i] != null ? arguments[i] : {};
        var ownKeys = Object.keys(source);
        if (typeof Object.getOwnPropertySymbols === "function") {
            ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function(sym) {
                return Object.getOwnPropertyDescriptor(source, sym).enumerable;
            }));
        }
        ownKeys.forEach(function(key) {
            _define_property$1(target, key, source[key]);
        });
    }
    return target;
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        keys.push.apply(keys, symbols);
    }
    return keys;
}
function _object_spread_props(target, source) {
    source = source != null ? source : {};
    if (Object.getOwnPropertyDescriptors) {
        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
        ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _possible_constructor_return(self, call) {
    if (call && (_type_of(call) === "object" || typeof call === "function")) {
        return call;
    }
    return _assert_this_initialized(self);
}
function _set_prototype_of(o, p) {
    _set_prototype_of = Object.setPrototypeOf || function setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
    };
    return _set_prototype_of(o, p);
}
function _sliced_to_array$1(arr, i) {
    return _array_with_holes$1(arr) || _iterable_to_array_limit$1(arr, i) || _unsupported_iterable_to_array$1(arr, i) || _non_iterable_rest$1();
}
function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol ? "symbol" : typeof obj;
}
function _unsupported_iterable_to_array$1(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array$1(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array$1(o, minLen);
}
function _is_native_reflect_construct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;
    try {
        Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
        return true;
    } catch (e) {
        return false;
    }
}
function _create_super(Derived) {
    var hasNativeReflectConstruct = _is_native_reflect_construct();
    return function _createSuperInternal() {
        var Super = _get_prototype_of(Derived), result;
        if (hasNativeReflectConstruct) {
            var NewTarget = _get_prototype_of(this).constructor;
            result = Reflect.construct(Super, arguments, NewTarget);
        } else {
            result = Super.apply(this, arguments);
        }
        return _possible_constructor_return(this, result);
    };
}
function _ts_generator$1(thisArg, body) {
    var f, y, t, g, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    };
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(_)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
/**
 * LocalShellSandbox - A concrete sandbox implementation for local shell execution.
 *
 * Extends BaseSandbox to provide command execution in a specified working directory.
 * All file operations (read, write, ls, grep, glob) are automatically implemented
 * by BaseSandbox using shell commands, so we only need to implement:
 * - execute(): Run shell commands
 * - uploadFiles(): Write files to the sandbox
 * - downloadFiles(): Read files from the sandbox
 */ var LocalShellSandbox = /*#__PURE__*/ function(BaseSandbox) {
    _inherits(LocalShellSandbox, BaseSandbox);
    var _super = _create_super(LocalShellSandbox);
    function LocalShellSandbox(options) {
        _class_call_check$2(this, LocalShellSandbox);
        var _this;
        _this = _super.call(this);
        _define_property$1(_assert_this_initialized(_this), "id", void 0);
        _define_property$1(_assert_this_initialized(_this), "managedServices", new Map());
        _this.workingDirectory = path.resolve(options.workingDirectory);
        _this.id = "local-shell-".concat(_this.workingDirectory.replace(/[^a-zA-Z0-9]/g, "-"));
        // Ensure working directory exists
        if (!fs.existsSync(_this.workingDirectory)) {
            fs.mkdirSync(_this.workingDirectory, {
                recursive: true
            });
        }
        return _this;
    }
    _create_class$1(LocalShellSandbox, [
        {
            key: "execute",
            value: /**
     * Execute a shell command in the sandbox.
     *
     * Uses /bin/bash to run commands with proper shell interpretation.
     * Captures both stdout and stderr, respects timeout.
     */ function execute(command, options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    return _ts_generator$1(this, function(_state) {
                        return [
                            2,
                            _this.runCommand(command, undefined, options)
                        ];
                    });
                })();
            }
        },
        {
            key: "streamExecute",
            value: function streamExecute(command, onLine, options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    return _ts_generator$1(this, function(_state) {
                        return [
                            2,
                            _this.runCommand(command, onLine, options)
                        ];
                    });
                })();
            }
        },
        {
            key: "open",
            value: function open(options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    return _ts_generator$1(this, function(_state) {
                        return [
                            2,
                            openLocalTerminal(_this.workingDirectory, options)
                        ];
                    });
                })();
            }
        },
        {
            key: "startService",
            value: function startService(options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var _options_onStateChange, _options_onStateChange1, cwd, readyText, logPaths, stdoutFd, stderrFd, _process_env_HOME, env, child, _options_port, initialState, resolveExitPromise, exitPromise, exitResolved, _options_port1, _options_port2, record, _options_port3, error, _options_port4, runningState, managedRecord, _options_port5;
                    return _ts_generator$1(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                cwd = path.resolve(options.cwd || _this.workingDirectory);
                                readyText = normalizeServiceReadyText(options.readyPattern);
                                if (!options.port) return [
                                    3,
                                    2
                                ];
                                return [
                                    4,
                                    ensurePortIsAvailable(options.port)
                                ];
                            case 1:
                                _state.sent();
                                _state.label = 2;
                            case 2:
                                logPaths = resolveServiceLogPaths(options.metadata, cwd, options.serviceId);
                                ensureServiceLogDirectory(logPaths);
                                stdoutFd = fs.openSync(logPaths.stdoutPath, "a");
                                stderrFd = fs.openSync(logPaths.stderrPath, "a");
                                env = _object_spread(_object_spread_props(_object_spread({}, process.env), {
                                    HOME: (_process_env_HOME = process.env["HOME"]) !== null && _process_env_HOME !== void 0 ? _process_env_HOME : os.homedir()
                                }), normalizeServiceEnv(options.env));
                                child = cp.spawn("/bin/bash", [
                                    "-c",
                                    options.command
                                ], {
                                    cwd: cwd,
                                    detached: process.platform !== "win32",
                                    env: env,
                                    stdio: [
                                        "ignore",
                                        stdoutFd,
                                        stderrFd
                                    ]
                                });
                                fs.closeSync(stdoutFd);
                                fs.closeSync(stderrFd);
                                initialState = {
                                    actualPort: (_options_port = options.port) !== null && _options_port !== void 0 ? _options_port : null,
                                    runtimeRef: child.pid ? {
                                        pid: child.pid,
                                        pgid: child.pid
                                    } : null,
                                    startedAt: new Date(),
                                    status: "starting",
                                    stoppedAt: null,
                                    transportMode: options.port ? "http" : "none"
                                };
                                resolveExitPromise = null;
                                exitPromise = new Promise(function(resolve) {
                                    resolveExitPromise = resolve;
                                });
                                exitResolved = false;
                                record = {
                                    actualPort: (_options_port1 = options.port) !== null && _options_port1 !== void 0 ? _options_port1 : null,
                                    child: child,
                                    cwd: cwd,
                                    exitPromise: exitPromise,
                                    logPaths: logPaths,
                                    requestedPort: (_options_port2 = options.port) !== null && _options_port2 !== void 0 ? _options_port2 : null,
                                    resolveExit: function(change) {
                                        var _options_onStateChange;
                                        if (exitResolved) {
                                            return;
                                        }
                                        exitResolved = true;
                                        record.status = change;
                                        _this.managedServices.delete(options.serviceId);
                                        void ((_options_onStateChange = options.onStateChange) === null || _options_onStateChange === void 0 ? void 0 : _options_onStateChange.call(options, change));
                                        resolveExitPromise === null || resolveExitPromise === void 0 ? void 0 : resolveExitPromise(change);
                                    },
                                    status: initialState
                                };
                                _this.managedServices.set(options.serviceId, record);
                                child.once("error", function(error) {
                                    var _options_port;
                                    record.resolveExit({
                                        actualPort: (_options_port = options.port) !== null && _options_port !== void 0 ? _options_port : null,
                                        exitCode: 1,
                                        runtimeRef: initialState.runtimeRef,
                                        signal: null,
                                        status: "failed",
                                        stoppedAt: new Date(),
                                        transportMode: initialState.transportMode
                                    });
                                    fs.appendFileSync(logPaths.stderrPath, "".concat(error.message, "\n"));
                                });
                                child.once("exit", function(exitCode, signal) {
                                    var _options_port;
                                    record.resolveExit({
                                        actualPort: (_options_port = options.port) !== null && _options_port !== void 0 ? _options_port : null,
                                        exitCode: exitCode,
                                        runtimeRef: initialState.runtimeRef,
                                        signal: signal,
                                        status: exitCode === 0 || record.status.status === "stopping" ? "stopped" : "failed",
                                        stoppedAt: new Date(),
                                        transportMode: initialState.transportMode
                                    });
                                });
                                child.unref();
                                return [
                                    4,
                                    (_options_onStateChange = options.onStateChange) === null || _options_onStateChange === void 0 ? void 0 : _options_onStateChange.call(options, initialState)
                                ];
                            case 3:
                                _state.sent();
                                _state.label = 4;
                            case 4:
                                _state.trys.push([
                                    4,
                                    6,
                                    ,
                                    8
                                ]);
                                return [
                                    4,
                                    _this.waitForServiceReady({
                                        logPaths: logPaths,
                                        port: (_options_port3 = options.port) !== null && _options_port3 !== void 0 ? _options_port3 : null,
                                        processId: child.pid,
                                        readyPattern: readyText
                                    })
                                ];
                            case 5:
                                _state.sent();
                                return [
                                    3,
                                    8
                                ];
                            case 6:
                                error = _state.sent();
                                try {
                                    killProcessGroup(child.pid, "SIGTERM");
                                } catch (killError) {
                                    if (!isProcessMissingError(killError)) {
                                        throw killError;
                                    }
                                }
                                return [
                                    4,
                                    exitPromise
                                ];
                            case 7:
                                _state.sent();
                                throw error;
                            case 8:
                                runningState = {
                                    actualPort: (_options_port4 = options.port) !== null && _options_port4 !== void 0 ? _options_port4 : null,
                                    runtimeRef: initialState.runtimeRef,
                                    startedAt: initialState.startedAt,
                                    status: "running",
                                    stoppedAt: null,
                                    transportMode: initialState.transportMode
                                };
                                managedRecord = _this.managedServices.get(options.serviceId);
                                if (managedRecord) {
                                    managedRecord.status = runningState;
                                    managedRecord.actualPort = (_options_port5 = options.port) !== null && _options_port5 !== void 0 ? _options_port5 : null;
                                }
                                return [
                                    4,
                                    (_options_onStateChange1 = options.onStateChange) === null || _options_onStateChange1 === void 0 ? void 0 : _options_onStateChange1.call(options, runningState)
                                ];
                            case 9:
                                _state.sent();
                                return [
                                    2,
                                    runningState
                                ];
                        }
                    });
                })();
            }
        },
        {
            key: "listServices",
            value: function listServices(options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var services;
                    return _ts_generator$1(this, function(_state) {
                        services = options.services.map(function(service) {
                            var managedService = service.id ? _this.managedServices.get(service.id) : null;
                            if (managedService) {
                                var _managedService_actualPort, _ref, _managedService_status_runtimeRef, _ref1, _managedService_status_startedAt, _ref2, _managedService_status_stoppedAt, _ref3, _managedService_status_transportMode, _ref4;
                                return _object_spread_props(_object_spread({}, service), {
                                    actualPort: (_ref = (_managedService_actualPort = managedService.actualPort) !== null && _managedService_actualPort !== void 0 ? _managedService_actualPort : service.actualPort) !== null && _ref !== void 0 ? _ref : null,
                                    runtimeRef: (_ref1 = (_managedService_status_runtimeRef = managedService.status.runtimeRef) !== null && _managedService_status_runtimeRef !== void 0 ? _managedService_status_runtimeRef : service.runtimeRef) !== null && _ref1 !== void 0 ? _ref1 : null,
                                    startedAt: (_ref2 = (_managedService_status_startedAt = managedService.status.startedAt) !== null && _managedService_status_startedAt !== void 0 ? _managedService_status_startedAt : service.startedAt) !== null && _ref2 !== void 0 ? _ref2 : null,
                                    status: managedService.status.status,
                                    stoppedAt: (_ref3 = (_managedService_status_stoppedAt = managedService.status.stoppedAt) !== null && _managedService_status_stoppedAt !== void 0 ? _managedService_status_stoppedAt : service.stoppedAt) !== null && _ref3 !== void 0 ? _ref3 : null,
                                    transportMode: (_ref4 = (_managedService_status_transportMode = managedService.status.transportMode) !== null && _managedService_status_transportMode !== void 0 ? _managedService_status_transportMode : service.transportMode) !== null && _ref4 !== void 0 ? _ref4 : null
                                });
                            }
                            if (service.status === "running" || service.status === "starting" || service.status === "stopping") {
                                return _object_spread_props(_object_spread({}, service), {
                                    status: "lost"
                                });
                            }
                            return service;
                        });
                        return [
                            2,
                            {
                                services: services
                            }
                        ];
                    });
                })();
            }
        },
        {
            key: "getServiceLogs",
            value: function getServiceLogs(options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var tail, _options_service_id, logPaths;
                    return _ts_generator$1(this, function(_state) {
                        tail = options.tail && options.tail > 0 ? Math.trunc(options.tail) : 200;
                        logPaths = resolveServiceLogPaths(options.service.metadata, options.service.workingDirectory || _this.workingDirectory, (_options_service_id = options.service.id) !== null && _options_service_id !== void 0 ? _options_service_id : "service");
                        return [
                            2,
                            {
                                stderr: readLogTail(logPaths.stderrPath, tail),
                                stdout: readLogTail(logPaths.stdoutPath, tail)
                            }
                        ];
                    });
                })();
            }
        },
        {
            key: "stopService",
            value: function stopService(options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var _options_onStateChange, serviceId, managedService, _options_onStateChange1, _options_service_actualPort, _options_service_runtimeRef, _options_service_transportMode, lostState, _managedService_actualPort, _managedService_status_runtimeRef, _managedService_status_transportMode, stoppingState, timeoutPromise;
                    return _ts_generator$1(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                serviceId = options.service.id;
                                if (!serviceId) {
                                    return [
                                        2,
                                        {
                                            status: "stopped",
                                            stoppedAt: new Date()
                                        }
                                    ];
                                }
                                managedService = _this.managedServices.get(serviceId);
                                if (!!managedService) return [
                                    3,
                                    2
                                ];
                                lostState = {
                                    actualPort: (_options_service_actualPort = options.service.actualPort) !== null && _options_service_actualPort !== void 0 ? _options_service_actualPort : null,
                                    runtimeRef: (_options_service_runtimeRef = options.service.runtimeRef) !== null && _options_service_runtimeRef !== void 0 ? _options_service_runtimeRef : null,
                                    status: options.service.status === "failed" ? "failed" : "lost",
                                    stoppedAt: new Date(),
                                    transportMode: (_options_service_transportMode = options.service.transportMode) !== null && _options_service_transportMode !== void 0 ? _options_service_transportMode : null
                                };
                                return [
                                    4,
                                    (_options_onStateChange1 = options.onStateChange) === null || _options_onStateChange1 === void 0 ? void 0 : _options_onStateChange1.call(options, lostState)
                                ];
                            case 1:
                                _state.sent();
                                return [
                                    2,
                                    lostState
                                ];
                            case 2:
                                stoppingState = {
                                    actualPort: (_managedService_actualPort = managedService.actualPort) !== null && _managedService_actualPort !== void 0 ? _managedService_actualPort : null,
                                    runtimeRef: (_managedService_status_runtimeRef = managedService.status.runtimeRef) !== null && _managedService_status_runtimeRef !== void 0 ? _managedService_status_runtimeRef : null,
                                    status: "stopping",
                                    stoppedAt: null,
                                    transportMode: (_managedService_status_transportMode = managedService.status.transportMode) !== null && _managedService_status_transportMode !== void 0 ? _managedService_status_transportMode : null
                                };
                                managedService.status = stoppingState;
                                return [
                                    4,
                                    (_options_onStateChange = options.onStateChange) === null || _options_onStateChange === void 0 ? void 0 : _options_onStateChange.call(options, stoppingState)
                                ];
                            case 3:
                                _state.sent();
                                try {
                                    killProcessGroup(managedService.child.pid, "SIGTERM");
                                } catch (error) {
                                    if (!isProcessMissingError(error)) {
                                        throw error;
                                    }
                                }
                                timeoutPromise = sleep(5000).then(function() {
                                    try {
                                        killProcessGroup(managedService.child.pid, "SIGKILL");
                                    } catch (error) {
                                        if (!isProcessMissingError(error)) {
                                            throw error;
                                        }
                                    }
                                    return managedService.exitPromise;
                                });
                                return [
                                    2,
                                    Promise.race([
                                        managedService.exitPromise,
                                        timeoutPromise.then(function(result) {
                                            return result;
                                        })
                                    ])
                                ];
                        }
                    });
                })();
            }
        },
        {
            key: "restartService",
            value: function restartService(options) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var _options_service_id;
                    return _ts_generator$1(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                return [
                                    4,
                                    _this.stopService({
                                        onStateChange: options.onStateChange,
                                        service: options.service
                                    })
                                ];
                            case 1:
                                _state.sent();
                                return [
                                    2,
                                    _this.startService({
                                        command: options.command,
                                        cwd: options.cwd,
                                        env: options.env,
                                        metadata: options.metadata,
                                        onStateChange: options.onStateChange,
                                        port: options.port,
                                        previewPath: options.previewPath,
                                        readyPattern: options.readyPattern,
                                        serviceId: (_options_service_id = options.service.id) !== null && _options_service_id !== void 0 ? _options_service_id : ""
                                    })
                                ];
                        }
                    });
                })();
            }
        },
        {
            key: "proxyServiceRequest",
            value: function proxyServiceRequest(request) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var serviceId, managedService, _managedService_actualPort, port, headers;
                    return _ts_generator$1(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                serviceId = request.service.id;
                                managedService = serviceId ? _this.managedServices.get(serviceId) : null;
                                if (!managedService || managedService.status.status !== "running") {
                                    request.response.statusCode = 502;
                                    request.response.setHeader("content-type", "text/plain; charset=utf-8");
                                    request.response.end("The selected sandbox service is not running.");
                                    return [
                                        2
                                    ];
                                }
                                port = (_managedService_actualPort = managedService.actualPort) !== null && _managedService_actualPort !== void 0 ? _managedService_actualPort : managedService.requestedPort;
                                if (!isFiniteNumber(port) || port <= 0) {
                                    request.response.statusCode = 502;
                                    request.response.setHeader("content-type", "text/plain; charset=utf-8");
                                    request.response.end("The selected sandbox service does not expose an HTTP port.");
                                    return [
                                        2
                                    ];
                                }
                                headers = _object_spread({}, request.request.headers);
                                delete headers.authorization;
                                delete headers.connection;
                                delete headers.cookie;
                                delete headers["keep-alive"];
                                delete headers["proxy-authenticate"];
                                delete headers["proxy-authorization"];
                                delete headers["x-api-key"];
                                delete headers["x-auth-token"];
                                delete headers["x-client-secret"];
                                delete headers["x-csrf-token"];
                                delete headers["x-xsrf-token"];
                                delete headers.trailer;
                                delete headers["transfer-encoding"];
                                delete headers.upgrade;
                                delete headers["accept-encoding"];
                                headers.host = "127.0.0.1:".concat(port);
                                return [
                                    4,
                                    new Promise(function(resolve) {
                                        var upstream = http.request({
                                            headers: headers,
                                            host: "127.0.0.1",
                                            method: request.request.method,
                                            path: request.path,
                                            port: port
                                        }, function(upstreamResponse) {
                                            var proxyBasePath = normalizePreviewProxyBasePath(request.service);
                                            var rewriteBody = Boolean(proxyBasePath && shouldRewritePreviewResponse(upstreamResponse.headers, request.request.method));
                                            var _upstreamResponse_statusCode;
                                            request.response.statusCode = (_upstreamResponse_statusCode = upstreamResponse.statusCode) !== null && _upstreamResponse_statusCode !== void 0 ? _upstreamResponse_statusCode : 502;
                                            var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                                            try {
                                                for(var _iterator = Object.entries(upstreamResponse.headers)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                                                    var _step_value = _sliced_to_array$1(_step.value, 2), name = _step_value[0], value = _step_value[1];
                                                    if (value !== undefined && shouldForwardProxyResponseHeader(name, rewriteBody)) {
                                                        request.response.setHeader(name, value);
                                                    }
                                                }
                                            } catch (err) {
                                                _didIteratorError = true;
                                                _iteratorError = err;
                                            } finally{
                                                try {
                                                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                                                        _iterator.return();
                                                    }
                                                } finally{
                                                    if (_didIteratorError) {
                                                        throw _iteratorError;
                                                    }
                                                }
                                            }
                                            if (!rewriteBody || !proxyBasePath) {
                                                upstreamResponse.pipe(request.response);
                                                upstreamResponse.on("end", function() {
                                                    return resolve();
                                                });
                                                return;
                                            }
                                            var chunks = [];
                                            upstreamResponse.on("data", function(chunk) {
                                                chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
                                            });
                                            upstreamResponse.on("end", function() {
                                                request.response.end(rewritePreviewTextResponse(Buffer.concat(chunks).toString("utf8"), proxyBasePath));
                                                resolve();
                                            });
                                        });
                                        upstream.on("error", function(error) {
                                            if (!request.response.headersSent) {
                                                request.response.statusCode = 502;
                                                request.response.setHeader("content-type", "text/plain; charset=utf-8");
                                            }
                                            request.response.end("Failed to proxy sandbox service request: ".concat(error.message));
                                            resolve();
                                        });
                                        if (request.request.readableEnded || request.request.method === "GET" || request.request.method === "HEAD") {
                                            upstream.end();
                                        } else {
                                            request.request.pipe(upstream);
                                        }
                                    })
                                ];
                            case 1:
                                _state.sent();
                                return [
                                    2
                                ];
                        }
                    });
                })();
            }
        },
        {
            key: "waitForServiceReady",
            value: function waitForServiceReady(params) {
                return _async_to_generator$1(function() {
                    var readyText, deadline;
                    return _ts_generator$1(this, function(_state) {
                        switch(_state.label){
                            case 0:
                                readyText = normalizeServiceReadyText(params.readyPattern);
                                deadline = Date.now() + 30000;
                                _state.label = 1;
                            case 1:
                                if (!(Date.now() < deadline)) return [
                                    3,
                                    9
                                ];
                                if (!params.port) return [
                                    3,
                                    5
                                ];
                                _state.label = 2;
                            case 2:
                                _state.trys.push([
                                    2,
                                    4,
                                    ,
                                    5
                                ]);
                                return [
                                    4,
                                    waitForPort(params.port, 300)
                                ];
                            case 3:
                                _state.sent();
                                return [
                                    2
                                ];
                            case 4:
                                _state.sent();
                                return [
                                    3,
                                    5
                                ];
                            case 5:
                                if (readyText && doesServiceLogMatch(params.logPaths, readyText)) {
                                    return [
                                        2
                                    ];
                                }
                                if (!(!params.port && !readyText)) return [
                                    3,
                                    7
                                ];
                                return [
                                    4,
                                    sleep(300)
                                ];
                            case 6:
                                _state.sent();
                                if (params.processId) {
                                    try {
                                        process.kill(params.processId, 0);
                                    } catch (error) {
                                        if (isProcessMissingError(error)) {
                                            throw new Error("The sandbox service exited before it became ready.");
                                        }
                                        throw error;
                                    }
                                }
                                return [
                                    2
                                ];
                            case 7:
                                if (params.processId) {
                                    try {
                                        process.kill(params.processId, 0);
                                    } catch (error) {
                                        if (isProcessMissingError(error)) {
                                            throw new Error("The sandbox service exited before it became ready.");
                                        }
                                        throw error;
                                    }
                                }
                                return [
                                    4,
                                    sleep(250)
                                ];
                            case 8:
                                _state.sent();
                                return [
                                    3,
                                    1
                                ];
                            case 9:
                                throw new Error("Timed out while waiting for the sandbox service to become ready.");
                        }
                    });
                })();
            }
        },
        {
            key: "runCommand",
            value: function runCommand(command, onChunk, executionOptions) {
                var _this = this;
                return new Promise(function(resolve) {
                    var resolvedOptions = pluginSdk.resolveSandboxExecutionOptions(executionOptions, pluginSdk.DEFAULT_SANDBOX_SHELL_EXECUTION_OPTIONS);
                    var chunks = [];
                    var truncated = false;
                    var totalBytes = 0;
                    var lineBuffer = "";
                    var settled = false;
                    var timedOut = false;
                    var forceKillTimer = null;
                    var child = cp.spawn("/bin/bash", [
                        "-c",
                        command
                    ], {
                        cwd: _this.workingDirectory,
                        env: _object_spread_props(_object_spread({}, process.env), {
                            HOME: process.env["HOME"]
                        }),
                        detached: process.platform !== "win32"
                    });
                    var timeoutMessage = pluginSdk.buildSandboxTimeoutMessage("Command", resolvedOptions.timeoutMs);
                    var buildTimeoutResponse = function() {
                        return {
                            output: pluginSdk.appendSandboxMessage(chunks.join(""), timeoutMessage),
                            exitCode: null,
                            truncated: truncated,
                            timedOut: true
                        };
                    };
                    var collectOutput = function(data) {
                        var str = data.toString();
                        totalBytes += data.byteLength;
                        if (totalBytes <= resolvedOptions.maxOutputBytes) {
                            chunks.push(str);
                        } else {
                            truncated = true;
                        }
                        if (onChunk) {
                            lineBuffer += str.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
                            var lines = lineBuffer.split("\n");
                            var _lines_pop;
                            lineBuffer = (_lines_pop = lines.pop()) !== null && _lines_pop !== void 0 ? _lines_pop : "";
                            var _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                            try {
                                for(var _iterator = lines[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                                    var line = _step.value;
                                    onChunk(line);
                                }
                            } catch (err) {
                                _didIteratorError = true;
                                _iteratorError = err;
                            } finally{
                                try {
                                    if (!_iteratorNormalCompletion && _iterator.return != null) {
                                        _iterator.return();
                                    }
                                } finally{
                                    if (_didIteratorError) {
                                        throw _iteratorError;
                                    }
                                }
                            }
                        }
                    };
                    var finalize = function(response) {
                        if (settled) {
                            return;
                        }
                        settled = true;
                        clearTimeout(timer);
                        if (forceKillTimer) {
                            clearTimeout(forceKillTimer);
                        }
                        if (onChunk && lineBuffer) {
                            onChunk(lineBuffer);
                            lineBuffer = "";
                        }
                        resolve(response);
                    };
                    var killChild = function(signal) {
                        if (!child.pid) {
                            return;
                        }
                        try {
                            if (process.platform !== "win32") {
                                process.kill(-child.pid, signal);
                            } else {
                                child.kill(signal);
                            }
                        } catch (error) {
                            if (error.code !== "ESRCH") {
                                finalize({
                                    output: "Error terminating process: ".concat(error.message),
                                    exitCode: 1,
                                    truncated: false
                                });
                            }
                        }
                    };
                    child.stdout.on("data", collectOutput);
                    child.stderr.on("data", collectOutput);
                    var timer = setTimeout(function() {
                        timedOut = true;
                        killChild("SIGTERM");
                        forceKillTimer = setTimeout(function() {
                            killChild("SIGKILL");
                        }, 5000);
                    }, resolvedOptions.timeoutMs);
                    child.on("close", function(exitCode) {
                        if (forceKillTimer) {
                            clearTimeout(forceKillTimer);
                        }
                        finalize(timedOut ? buildTimeoutResponse() : {
                            output: chunks.join(""),
                            exitCode: exitCode,
                            truncated: truncated,
                            timedOut: false
                        });
                    });
                    child.on("error", function(err) {
                        if (forceKillTimer) {
                            clearTimeout(forceKillTimer);
                        }
                        finalize(timedOut ? buildTimeoutResponse() : {
                            output: "Error spawning process: ".concat(err.message),
                            exitCode: 1,
                            truncated: false
                        });
                    });
                });
            }
        },
        {
            key: "uploadFiles",
            value: /**
     * Upload files to the sandbox.
     *
     * Writes files to the working directory, creating parent directories as needed.
     */ function uploadFiles(files) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var results, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, _step_value, filePath, content, fullPath, parentDir, error;
                    return _ts_generator$1(this, function(_state) {
                        results = [];
                        _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                        try {
                            for(_iterator = files[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                                _step_value = _sliced_to_array$1(_step.value, 2), filePath = _step_value[0], content = _step_value[1];
                                try {
                                    fullPath = _this.resolveSandboxFilePath(filePath);
                                    parentDir = path.dirname(fullPath);
                                    // Ensure parent directory exists
                                    if (!fs.existsSync(parentDir)) {
                                        fs.mkdirSync(parentDir, {
                                            recursive: true
                                        });
                                    }
                                    fs.writeFileSync(fullPath, content);
                                    results.push({
                                        path: filePath,
                                        error: null
                                    });
                                } catch (err) {
                                    error = err;
                                    if (error.code === "EACCES") {
                                        results.push({
                                            path: filePath,
                                            error: "permission_denied"
                                        });
                                    } else if (error.code === "EISDIR") {
                                        results.push({
                                            path: filePath,
                                            error: "is_directory"
                                        });
                                    } else {
                                        results.push({
                                            path: filePath,
                                            error: "invalid_path"
                                        });
                                    }
                                }
                            }
                        } catch (err) {
                            _didIteratorError = true;
                            _iteratorError = err;
                        } finally{
                            try {
                                if (!_iteratorNormalCompletion && _iterator.return != null) {
                                    _iterator.return();
                                }
                            } finally{
                                if (_didIteratorError) {
                                    throw _iteratorError;
                                }
                            }
                        }
                        return [
                            2,
                            results
                        ];
                    });
                })();
            }
        },
        {
            key: "downloadFiles",
            value: /**
     * Download files from the sandbox.
     *
     * Reads files from the working directory.
     */ function downloadFiles(paths) {
                var _this = this;
                return _async_to_generator$1(function() {
                    var results, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, filePath, fullPath, stat, content, error;
                    return _ts_generator$1(this, function(_state) {
                        results = [];
                        _iteratorNormalCompletion = true, _didIteratorError = false, _iteratorError = undefined;
                        try {
                            for(_iterator = paths[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true){
                                filePath = _step.value;
                                try {
                                    fullPath = _this.resolveSandboxFilePath(filePath);
                                    if (!fs.existsSync(fullPath)) {
                                        results.push({
                                            path: filePath,
                                            content: null,
                                            error: "file_not_found"
                                        });
                                        continue;
                                    }
                                    stat = fs.statSync(fullPath);
                                    if (stat.isDirectory()) {
                                        results.push({
                                            path: filePath,
                                            content: null,
                                            error: "is_directory"
                                        });
                                        continue;
                                    }
                                    content = fs.readFileSync(fullPath);
                                    results.push({
                                        path: filePath,
                                        content: new Uint8Array(content),
                                        error: null
                                    });
                                } catch (err) {
                                    error = err;
                                    if (error.code === "EACCES") {
                                        results.push({
                                            path: filePath,
                                            content: null,
                                            error: "permission_denied"
                                        });
                                    } else if (error.code === "EINVAL") {
                                        results.push({
                                            path: filePath,
                                            content: null,
                                            error: "invalid_path"
                                        });
                                    } else {
                                        results.push({
                                            path: filePath,
                                            content: null,
                                            error: "file_not_found"
                                        });
                                    }
                                }
                            }
                        } catch (err) {
                            _didIteratorError = true;
                            _iteratorError = err;
                        } finally{
                            try {
                                if (!_iteratorNormalCompletion && _iterator.return != null) {
                                    _iterator.return();
                                }
                            } finally{
                                if (_didIteratorError) {
                                    throw _iteratorError;
                                }
                            }
                        }
                        return [
                            2,
                            results
                        ];
                    });
                })();
            }
        },
        {
            key: "resolveSandboxFilePath",
            value: function resolveSandboxFilePath(filePath) {
                var resolvedPath = path.resolve(this.workingDirectory, filePath);
                var relativePath = path.relative(this.workingDirectory, resolvedPath);
                if (relativePath.startsWith("..") || path.isAbsolute(relativePath)) {
                    var error = new Error("Path is outside of the sandbox working directory: ".concat(filePath));
                    error.code = "EINVAL";
                    throw error;
                }
                return resolvedPath;
            }
        }
    ]);
    return LocalShellSandbox;
} 
(pluginSdk.BaseSandbox);

var LOCAL_SHELL_SANDBOX_ICON = '<?xml version="1.0" encoding="utf-8"?>\n<!-- Generator: Adobe Illustrator 19.2.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\n<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\n<svg version="1.1" id="Layer_1" xmlns:x="&ns_extend;" xmlns:i="&ns_ai;" xmlns:graph="&ns_graphs;"\n	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512"\n	 style="enable-background:new 0 0 512 512;" xml:space="preserve">\n<style type="text/css">\n	.Drop_x0020_Shadow{fill:none;}\n	.Round_x0020_Corners_x0020_2_x0020_pt{fill:#FFFFFF;stroke:#1B1B1F;stroke-miterlimit:10;}\n	.Live_x0020_Reflect_x0020_X{fill:none;}\n	.Bevel_x0020_Soft{fill:url(#SVGID_1_);}\n	.Dusk{fill:#FFFFFF;}\n	.Foliage_GS{fill:#FFDC00;}\n	.Pompadour_GS{fill-rule:evenodd;clip-rule:evenodd;fill:#58AEE2;}\n	.st0{fill:none;}\n	.st1{fill:#FFFFFF;}\n	.st2{fill:#283037;}\n	.st3{fill:#4DA825;}\n</style>\n<switch>\n	<foreignObject requiredExtensions="&ns_ai;" x="0" y="0" width="1" height="1">\n		<i:pgfRef  xlink:href="#adobe_illustrator_pgf">\n		</i:pgfRef>\n	</foreignObject>\n	<g i:extraneous="self">\n		<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0.7071" y2="0.7071">\n			<stop  offset="0" style="stop-color:#E6E6EA"/>\n			<stop  offset="0.1719" style="stop-color:#E2E2E6"/>\n			<stop  offset="0.3482" style="stop-color:#D7D6DA"/>\n			<stop  offset="0.5264" style="stop-color:#C4C2C5"/>\n			<stop  offset="0.7061" style="stop-color:#A9A7A8"/>\n			<stop  offset="0.8852" style="stop-color:#878484"/>\n			<stop  offset="1" style="stop-color:#6D6968"/>\n		</linearGradient>\n		<g>\n			<rect x="0.3" y="1.3" class="st0" width="512" height="512"/>\n			<g>\n				<g>\n					<path class="st1" d="M449.1,105.9L287.5,9.9c-19.3-11.5-43.1-11.5-62.4,0L63.5,105.9c-19.3,11.4-31.2,32.6-31.2,55.5v191.9\n						c0,22.9,11.9,44.1,31.2,55.5l161.6,95.9c9.6,5.7,20.4,8.6,31.2,8.6c10.8,0,21.5-2.9,31.2-8.6l161.6-95.9\n						c19.3-11.5,31.2-32.6,31.2-55.5V161.4C480.3,138.5,468.4,117.3,449.1,105.9z"/>\n				</g>\n				<g>\n					<path class="st2" d="M449.1,105.9L287.5,9.9c-9.6-5.7-20.4-8.6-31.2-8.6s-21.5,2.9-31.2,8.6L63.5,105.9\n						c-19.3,11.4-31.2,32.6-31.2,55.5v191.9c0,22.9,11.9,44.1,31.2,55.5l161.6,95.9c9.6,5.7,20.4,8.6,31.2,8.6\n						c10.8,0,21.5-2.9,31.2-8.6l161.6-95.9c19.3-11.5,31.2-32.6,31.2-55.5V161.4C480.3,138.5,468.4,117.3,449.1,105.9z M230.8,494.9\n						L69.2,399c-15.8-9.4-25.6-26.9-25.6-45.7V161.4c0-18.8,9.8-36.3,25.6-45.7l161.6-95.9c7.8-4.6,16.6-7,25.5-7s17.8,2.4,25.5,7\n						l161.6,95.9c13.3,7.9,22.3,21.6,24.8,37c-5.4-11.4-17.4-14.6-31.5-6.3l-152.9,94.5c-19.1,11.1-33.1,23.7-33.1,46.6v188.4\n						c0,13.8,5.5,22.7,14.1,25.3c-2.8,0.5-5.6,0.8-8.5,0.8C247.4,501.9,238.5,499.5,230.8,494.9z"/>\n				</g>\n				<g>\n					<path class="st3" d="M406.8,371.8l-40.3,24.1c-1.1,0.6-1.9,1.3-1.9,2.6v10.5c0,1.3,0.9,1.8,1.9,1.2l40.9-24.8\n						c1.1-0.6,1.2-1.8,1.2-3.1V373C408.7,371.7,407.8,371.2,406.8,371.8z"/>\n				</g>\n				<g>\n					<path class="st1" d="M321.1,283.2c1.3-0.7,2.4,0.2,2.4,1.9l0.1,13.9c5.8-2.3,10.9-2.9,15.5-1.9c1,0.3,1.4,1.6,1,3.2l-3.1,12.3\n						c-0.2,0.9-0.8,1.9-1.4,2.5c-0.3,0.3-0.5,0.5-0.8,0.6c-0.4,0.2-0.8,0.3-1.2,0.2c-2.1-0.5-7.1-1.6-14.9,2.4\n						c-8.2,4.2-11.1,11.3-11,16.6c0.1,6.3,3.3,8.3,14.5,8.4c14.9,0.2,21.4,6.8,21.5,21.8c0.2,14.8-7.7,30.6-19.8,40.4l0.3,13.8\n						c0,1.7-1.1,3.6-2.4,4.2l-8.2,4.7c-1.3,0.7-2.4-0.1-2.4-1.8l-0.1-13.6c-7,2.9-14.1,3.6-18.6,1.8c-0.9-0.3-1.2-1.6-0.9-3l3-12.5\n						c0.2-1,0.8-2,1.5-2.6c0.3-0.2,0.5-0.4,0.8-0.6c0.5-0.2,0.9-0.3,1.3-0.1c4.9,1.6,11.1,0.9,17.1-2.2c7.6-3.9,12.7-11.6,12.6-19.4\n						c-0.1-7-3.9-9.9-13.1-10c-11.7,0-22.7-2.3-22.9-19.6c-0.1-14.2,7.3-29,19-38.4l-0.1-13.9c0-1.7,1-3.6,2.4-4.3L321.1,283.2z"/>\n				</g>\n			</g>\n		</g>\n		<g>\n		</g>\n		<g>\n		</g>\n		<g>\n		</g>\n		<g>\n		</g>\n		<g>\n		</g>\n		<g>\n		</g>\n	</g>\n</switch>\n</svg>\n';

function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _array_with_holes(arr) {
    if (Array.isArray(arr)) return arr;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _class_call_check$1(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
function _defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    return Constructor;
}
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _instanceof(left, right) {
    if (right != null && typeof Symbol !== "undefined" && right[Symbol.hasInstance]) {
        return !!right[Symbol.hasInstance](left);
    } else {
        return left instanceof right;
    }
}
function _iterable_to_array(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _iterable_to_array_limit(arr, i) {
    var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];
    if (_i == null) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _s, _e;
    try {
        for(_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true){
            _arr.push(_s.value);
            if (i && _arr.length === i) break;
        }
    } catch (err) {
        _d = true;
        _e = err;
    } finally{
        try {
            if (!_n && _i["return"] != null) _i["return"]();
        } finally{
            if (_d) throw _e;
        }
    }
    return _arr;
}
function _non_iterable_rest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _sliced_to_array(arr, i) {
    return _array_with_holes(arr) || _iterable_to_array_limit(arr, i) || _unsupported_iterable_to_array(arr, i) || _non_iterable_rest();
}
function _to_array(arr) {
    return _array_with_holes(arr) || _iterable_to_array(arr) || _unsupported_iterable_to_array(arr) || _non_iterable_rest();
}
function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _array_like_to_array(o, minLen);
}
function _ts_generator(thisArg, body) {
    var f, y, t, g, _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    };
    return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(_)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
// Keep the existing identifier so saved Assistant sandbox settings remain compatible.
var LOCAL_SHELL_SANDBOX_PROVIDER = "local-shell-sandbox";
exports.LocalShellSandboxProvider = /*#__PURE__*/ function() {
    function LocalShellSandboxProvider() {
        _class_call_check$1(this, LocalShellSandboxProvider);
        _define_property(this, "type", LOCAL_SHELL_SANDBOX_PROVIDER);
        _define_property(this, "meta", {
            name: {
                en_US: "Local Shell Sandbox",
                zh_Hans: "本地 Shell 沙盒"
            },
            description: {
                en_US: "A sandbox that executes shell commands locally on the host machine.",
                zh_Hans: "在主机本地执行 shell 命令的沙盒。"
            },
            icon: {
                type: "svg",
                value: LOCAL_SHELL_SANDBOX_ICON
            }
        });
    }
    _create_class(LocalShellSandboxProvider, [
        {
            key: "isAvailable",
            value: function isAvailable() {
                var _process_env_XPERT_LOCAL_SANDBOX_ENABLED;
                return ((_process_env_XPERT_LOCAL_SANDBOX_ENABLED = process.env.XPERT_LOCAL_SANDBOX_ENABLED) === null || _process_env_XPERT_LOCAL_SANDBOX_ENABLED === void 0 ? void 0 : _process_env_XPERT_LOCAL_SANDBOX_ENABLED.trim().toLowerCase()) === "true";
            }
        },
        {
            key: "create",
            value: function create(options) {
                var _this = this;
                return _async_to_generator(function() {
                    var fallbackMessage, _options_workingDirectory;
                    return _ts_generator(this, function(_state) {
                        if (!_this.isAvailable()) {
                            fallbackMessage = "Sandbox provider is unavailable: " + _this.type;
                            throw new Error(i18next.t("server-ai:Error.SandboxProviderUnavailable", {
                                defaultValue: fallbackMessage,
                                provider: _this.type
                            }) || fallbackMessage);
                        }
                        if ((options === null || options === void 0 ? void 0 : options.workFor.type) === "job" && process.env.NODE_ENV === "production") {
                            throw new Error("Local Shell Sandbox Jobs are disabled in production.");
                        }
                        return [
                            2,
                            new LocalShellSandbox({
                                workingDirectory: (_options_workingDirectory = options === null || options === void 0 ? void 0 : options.workingDirectory) !== null && _options_workingDirectory !== void 0 ? _options_workingDirectory : _this.getDefaultWorkingDir()
                            })
                        ];
                    });
                })();
            }
        },
        {
            key: "getProfileHealth",
            value: function getProfileHealth(input) {
                return _async_to_generator(function() {
                    var _input_manifestCommand, _ref, executable, args, parsed, manifest, _input_expectedManifest, mismatch;
                    return _ts_generator(this, function(_state) {
                        if (process.env.NODE_ENV === "production") {
                            return [
                                2,
                                {
                                    available: false,
                                    reason: "Local Shell Sandbox Job profiles are disabled in production."
                                }
                            ];
                        }
                        _ref = _to_array((_input_manifestCommand = input.manifestCommand) !== null && _input_manifestCommand !== void 0 ? _input_manifestCommand : []), executable = _ref[0], args = _ref.slice(1);
                        if (!executable) return [
                            2,
                            {
                                available: false,
                                reason: "Profile ".concat(input.profile, " has no manifest command configured.")
                            }
                        ];
                        try {
                            parsed = JSON.parse(cp.execFileSync(executable, args, {
                                encoding: "utf8"
                            }));
                            if (!isStringRecord(parsed)) return [
                                2,
                                {
                                    available: false,
                                    reason: "Profile ".concat(input.profile, " returned an invalid manifest.")
                                }
                            ];
                            manifest = parsed;
                            ;
                            mismatch = Object.entries((_input_expectedManifest = input.expectedManifest) !== null && _input_expectedManifest !== void 0 ? _input_expectedManifest : {}).find(function(param) {
                                var _param = _sliced_to_array(param, 2), key = _param[0], value = _param[1];
                                return manifest[key] !== value;
                            });
                            return [
                                2,
                                mismatch ? {
                                    available: false,
                                    reason: "Runner manifest ".concat(mismatch[0], " does not match ").concat(mismatch[1], "."),
                                    manifest: manifest
                                } : {
                                    available: true,
                                    manifest: manifest
                                }
                            ];
                        } catch (error) {
                            return [
                                2,
                                {
                                    available: false,
                                    reason: _instanceof(error, Error) ? error.message : String(error)
                                }
                            ];
                        }
                        return [
                            2
                        ];
                    });
                })();
            }
        },
        {
            key: "getDefaultWorkingDir",
            value: function getDefaultWorkingDir() {
                return path.resolve(process.cwd(), "sandbox");
            }
        }
    ]);
    return LocalShellSandboxProvider;
}();
exports.LocalShellSandboxProvider = __decorate([
    common.Injectable(),
    pluginSdk.SandboxProviderStrategy(LOCAL_SHELL_SANDBOX_PROVIDER)
], exports.LocalShellSandboxProvider);
function isStringRecord(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value) && Object.values(value).every(function(item) {
        return typeof item === "string";
    });
}

function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
    }
}
var PLUGIN_ARTIFACT_NAMESPACE = "local_shell_sandbox";
exports.LocalShellSandboxPlugin = function LocalShellSandboxPlugin() {
    _class_call_check(this, LocalShellSandboxPlugin);
};
exports.LocalShellSandboxPlugin = __decorate([
    pluginSdk.XpertServerPlugin({
        providers: [
            exports.LocalShellSandboxProvider
        ],
        exports: [
            exports.LocalShellSandboxProvider
        ]
    })
], exports.LocalShellSandboxPlugin);
var plugin = {
    meta: {
        name: manifest.name,
        version: manifest.version,
        level: "system",
        artifactNamespace: PLUGIN_ARTIFACT_NAMESPACE,
        category: "integration",
        author: "XpertAI",
        displayName: {
            en_US: "Local Shell Sandbox",
            zh_Hans: "本地 Shell 沙盒"
        },
        description: {
            en_US: "Run commands and interactive terminals on the API host.",
            zh_Hans: "在 API 主机上执行命令并使用交互式终端。"
        }
    },
    config: {
        schema: zod.z.object({})
    },
    register: function register() {
        return {
            module: exports.LocalShellSandboxPlugin,
            global: true
        };
    }
};

exports.LocalShellSandbox = LocalShellSandbox;
exports.PLUGIN_ARTIFACT_NAMESPACE = PLUGIN_ARTIFACT_NAMESPACE;
exports.default = plugin;

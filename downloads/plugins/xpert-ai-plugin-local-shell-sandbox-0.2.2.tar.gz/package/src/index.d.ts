import type { XpertPlugin } from '@xpert-ai/plugin-sdk';
export declare const PLUGIN_ARTIFACT_NAMESPACE = "local_shell_sandbox";
export declare class LocalShellSandboxPlugin {
}
declare const plugin: XpertPlugin;
export default plugin;
export { LocalShellSandbox, LocalShellSandboxProvider } from './lib/local-shell-sandbox.provider';

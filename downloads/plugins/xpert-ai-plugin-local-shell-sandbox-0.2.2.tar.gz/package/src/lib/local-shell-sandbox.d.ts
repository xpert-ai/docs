import { BaseSandbox, ExecuteResponse, FileDownloadResponse, FileUploadResponse, SandboxManagedServiceAdapter, SandboxManagedServiceListOptions, SandboxManagedServiceListResult, SandboxManagedServiceLogsOptions, SandboxManagedServiceRestartOptions, SandboxManagedServiceStartOptions, SandboxManagedServiceStartResult, SandboxManagedServiceStateChange, SandboxManagedServiceStopOptions, SandboxServiceProxyAdapter, SandboxServiceProxyRequest, SandboxExecutionOptions } from '@xpert-ai/plugin-sdk';
import type { SandboxTerminalAdapter, SandboxTerminalOpenOptions, SandboxTerminalSession } from '@xpert-ai/plugin-sdk';
import type { TSandboxManagedServiceLogs } from '@xpert-ai/contracts';
/**
 * LocalShellSandbox - A concrete sandbox implementation for local shell execution.
 *
 * Extends BaseSandbox to provide command execution in a specified working directory.
 * All file operations (read, write, ls, grep, glob) are automatically implemented
 * by BaseSandbox using shell commands, so we only need to implement:
 * - execute(): Run shell commands
 * - uploadFiles(): Write files to the sandbox
 * - downloadFiles(): Read files from the sandbox
 */
export declare class LocalShellSandbox extends BaseSandbox implements SandboxManagedServiceAdapter, SandboxServiceProxyAdapter, SandboxTerminalAdapter {
    readonly id: string;
    private readonly managedServices;
    /**
     * Create a new LocalShellSandbox.
     *
     * @param options - Configuration options
     * @param options.workingDirectory - Directory where commands will be executed
     */
    constructor(options: {
        workingDirectory: string;
    });
    /**
     * Execute a shell command in the sandbox.
     *
     * Uses /bin/bash to run commands with proper shell interpretation.
     * Captures both stdout and stderr, respects timeout.
     */
    execute(command: string, options?: SandboxExecutionOptions): Promise<ExecuteResponse>;
    streamExecute(command: string, onLine: (line: string) => void, options?: SandboxExecutionOptions): Promise<ExecuteResponse>;
    open(options: SandboxTerminalOpenOptions): Promise<SandboxTerminalSession>;
    startService(options: SandboxManagedServiceStartOptions): Promise<SandboxManagedServiceStartResult>;
    listServices(options: SandboxManagedServiceListOptions): Promise<SandboxManagedServiceListResult>;
    getServiceLogs(options: SandboxManagedServiceLogsOptions): Promise<TSandboxManagedServiceLogs>;
    stopService(options: SandboxManagedServiceStopOptions): Promise<SandboxManagedServiceStateChange>;
    restartService(options: SandboxManagedServiceRestartOptions): Promise<SandboxManagedServiceStartResult>;
    proxyServiceRequest(request: SandboxServiceProxyRequest): Promise<void>;
    private waitForServiceReady;
    private runCommand;
    /**
     * Upload files to the sandbox.
     *
     * Writes files to the working directory, creating parent directories as needed.
     */
    uploadFiles(files: Array<[string, Uint8Array]>): Promise<FileUploadResponse[]>;
    /**
     * Download files from the sandbox.
     *
     * Reads files from the working directory.
     */
    downloadFiles(paths: string[]): Promise<FileDownloadResponse[]>;
    private resolveSandboxFilePath;
}

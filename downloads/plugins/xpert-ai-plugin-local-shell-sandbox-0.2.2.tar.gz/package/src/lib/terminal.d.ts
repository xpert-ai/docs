import type { SandboxTerminalOpenOptions, SandboxTerminalSession } from '@xpert-ai/plugin-sdk';
export declare function openLocalTerminal(workingDirectory: string, options: SandboxTerminalOpenOptions): Promise<SandboxTerminalSession>;

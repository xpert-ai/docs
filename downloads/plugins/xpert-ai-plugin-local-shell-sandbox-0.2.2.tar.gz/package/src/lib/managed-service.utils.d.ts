import cp from 'node:child_process';
import http from 'node:http';
import type { SandboxManagedServiceStateChange } from '@xpert-ai/plugin-sdk';
import type { ISandboxManagedService, TSandboxManagedServiceEnvEntry } from '@xpert-ai/contracts';
export type ManagedServiceLogPaths = {
    stderrPath: string;
    stdoutPath: string;
};
export type ManagedServiceMetadataCandidate = {
    logs?: {
        stderrPath?: unknown;
        stdoutPath?: unknown;
    };
};
export type LocalManagedServiceRecord = {
    actualPort?: number | null;
    child: cp.ChildProcess;
    cwd: string;
    exitPromise: Promise<SandboxManagedServiceStateChange>;
    logPaths: ManagedServiceLogPaths;
    requestedPort?: number | null;
    resolveExit: (change: SandboxManagedServiceStateChange) => void;
    status: SandboxManagedServiceStateChange;
};
export declare function isObjectLike(value: unknown): value is object;
export declare function isNonEmptyString(value: unknown): value is string;
export declare function isFiniteNumber(value: unknown): value is number;
export declare function normalizeHeaderValue(value: number | string | string[] | undefined): string;
export declare function shouldRewritePreviewResponse(headers: http.IncomingHttpHeaders, method: string | undefined): boolean;
export declare function shouldForwardProxyResponseHeader(name: string, rewriteBody: boolean): boolean;
export declare function normalizePreviewProxyBasePath(service: ISandboxManagedService): string | null;
export declare function rewritePreviewRootPath(pathname: string, proxyBasePath: string): string;
export declare function rewritePreviewTextResponse(content: string, proxyBasePath: string): string;
export declare function normalizeServiceEnv(entries: TSandboxManagedServiceEnvEntry[] | undefined): NodeJS.ProcessEnv;
export declare function isProcessMissingError(error: unknown): boolean;
export declare function killProcessGroup(processId: number | undefined, signal: NodeJS.Signals): void;
export declare function sleep(ms: number): Promise<void>;
export declare function resolveServiceLogPaths(metadata: ISandboxManagedService['metadata'], cwd: string, serviceId: string): ManagedServiceLogPaths;
export declare function ensureServiceLogDirectory(logPaths: ManagedServiceLogPaths): void;
export declare function readLogTail(filePath: string, maxLines: number): string;
export declare function normalizeServiceReadyText(value: string | null | undefined): string | null;
export declare function doesServiceLogMatch(logPaths: ManagedServiceLogPaths, readyText: string): boolean;
export declare function waitForPort(port: number, timeoutMs: number): Promise<void>;
export declare function ensurePortIsAvailable(port: number): Promise<void>;

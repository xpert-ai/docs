import type { ISandboxProvider, SandboxProviderCreateOptions } from '@xpert-ai/plugin-sdk';
import type { TSandboxProviderMeta } from '@xpert-ai/contracts';
import { LocalShellSandbox } from './local-shell-sandbox';
export declare const LOCAL_SHELL_SANDBOX_PROVIDER = "local-shell-sandbox";
export { LocalShellSandbox } from './local-shell-sandbox';
export declare class LocalShellSandboxProvider implements ISandboxProvider<LocalShellSandbox> {
    readonly type = "local-shell-sandbox";
    readonly meta: TSandboxProviderMeta;
    isAvailable(): boolean;
    create(options?: SandboxProviderCreateOptions): Promise<LocalShellSandbox>;
    getProfileHealth(input: {
        profile: string;
        image?: string;
        manifestCommand?: readonly string[];
        expectedManifest?: Record<string, string>;
    }): Promise<{
        available: boolean;
        reason?: string;
        manifest?: Record<string, string>;
    }>;
    getDefaultWorkingDir(): string;
}
